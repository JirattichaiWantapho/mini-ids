from scapy.all import conf
print(conf.ifaces)