import requests
import json

class WebhookClient:
    def __init__(self, webhook_url):
        self.webhook_url = webhook_url

    def send_alert(self, message, alert_type="ids_alert"):
        try:
            payload = {
                "message": message,
                "type": alert_type
            }
            response = requests.post(
                self.webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"}
            )
            response.raise_for_status()
            print(f"[WEBHOOK] Alert sent successfully")
        except Exception as e:
            print(f"[ERROR] Failed to send webhook: {e}")

__all__ = ['WebhookClient']