from flask import Flask, request
import json
import datetime
from linebot import LineBotApi
from linebot.models import TextSendMessage
import os

app = Flask(__name__)

alerts_history = []


LINE_CHANNEL_ACCESS_TOKEN = os.getenv("LINE_CHANNEL_ACCESS_TOKEN")
line_bot_api = LineBotApi(LINE_CHANNEL_ACCESS_TOKEN)

def send_line_message(message):
    """ส่งข้อความแจ้งเตือนไปยัง LINE"""
    try:
        user_id = os.getenv("LINE_USER_ID")
        line_bot_api.push_message(user_id, TextSendMessage(text=message))
        print("[LINE] Message sent successfully")
    except Exception as e:
        print(f"[LINE ERROR] Failed to send message: {e}")

@app.route('/webhook', methods=['POST'])
def webhook():
    if request.method == 'POST':
        data = request.json
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # เก็บข้อมูลการแจ้งเตือน
        alert_data = {
            'timestamp': timestamp,
            'message': data.get('message', ''),
            'type': data.get('type', 'unknown')
        }
        alerts_history.append(alert_data)
        
        # แสดงข้อมูลใน console
        print(f"[WEBHOOK] {timestamp} - {data.get('message')}")

        # ส่งข้อความไปยัง LINE
        send_line_message(f"[{alert_data['type']}] {alert_data['message']}")

        return 'OK', 200

@app.route('/alerts', methods=['GET'])
def get_alerts():
    return json.dumps(alerts_history)

@app.route('/', methods=['GET'])
def home():
    return 'Webhook Server is running!', 200

if __name__ == '__main__':
    print("="*50)
    print("Starting Webhook Server...")
    print("Server URL: http://localhost:5000")
    print("Endpoints:")
    print("  - POST /webhook : รับการแจ้งเตือน")
    print("  - GET /alerts  : ดูประวัติการแจ้งเตือน")
    print("  - GET /       : ตรวจสอบสถานะ server")
    print("="*50)
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
